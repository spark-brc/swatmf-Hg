# This is for only GUMU watershed optimization

import os
from datetime import datetime
import pyemu
import pandas as pd
from swatmf import swatmf_pst_par, swatmf_utils
from swatmf import swatmf_pst_utils
import glob
from tqdm import tqdm


wd = os.getcwd()
os.chdir(wd)
print(wd)

def get_hru_files():
    hru_files = [f for f in glob.glob("*.hru")]
    hru_fs = [hf for hf in hru_files if hf[0]=='0' and len(hf[:-4])==9]
    return hru_fs

def chg_fac():
    with open('hru_pars.in', 'r') as f:
        data = f.readlines()
        data1 = [x.split() for x in data]
        
    chgtype = data1[0][0][0].lower()
    val = data1[0][1]
    return chgtype, val


def hruSurlag():
    hru_files = get_hru_files()
    chgtype, fval = chg_fac()
    for hf in tqdm(hru_files):
        with open("backup/" + hf, 'r') as f:
            data = f.readlines()
            data1 = [x.split() for x in data]
        nlines = []
        for num, line in enumerate(data1):
            if line != [] and len(line) >= 3:
                if (line[1] == "|") and (line[2].lower() == "surlag:"):
                    nlines.append(num)
                    val = float(line[0])
        if chgtype == 'v':
            val = float(fval)
        if chgtype == 'r':
            val = val + (val*float(fval))
        with open(hf,'w') as wf:
            for d in data[:nlines[0]]:
                wf.write(str(d))
        with open(hf,'a') as af:
            af.write("{0:>16.1f}".format(val) +  "    | SURLAG: Surface runoff lag time in the HRU (days)\n")
        with open(hf,'a') as raf:
            for d in data[nlines[0]+1:]:
                raf.write(str(d))
    print("hru files have been updated ...")    

def hksy_postcal():

    df =  pd.read_csv('hksy_post_pars.in', sep=r'\s+', header=None)
    df['parnam'] = df.iloc[:, 0].str[-2:]
    df['chgtype'] = df.iloc[:, 0].str[:1]
    df['parval'] = df.iloc[:, 1].astype(float)
    df.set_index('parnam', inplace = True)

    for i in df.index:
        chgt = df.loc[i, 'chgtype']
        val = df.loc[i, 'parval']
        df_p = pd.read_csv(f'{i}0pp.dat.cal', sep=r'\s+', header=None)
        if chgt == 'r':
            new_vals = df_p.iloc[:, 4] + (df_p.iloc[:, 4] * float(val))

        df_p.iloc[:, 0] = df_p.iloc[:, 0].map(lambda x: '{:<12s}'.format(x)) 
        df_p.iloc[:, 1] = df_p.iloc[:, 1].map(lambda x: '{:<12.5e}'.format(x))
        df_p.iloc[:, 2] = df_p.iloc[:, 2].map(lambda x: '{:<12.5e}'.format(x))
        df_p.iloc[:, 3] = df_p.iloc[:, 3].map(lambda x: '{:<6d}'.format(x)) 
        df_p.iloc[:, 4] = new_vals.map(lambda x: '{:<12.5e}'.format(x))
        with open(f'{i}0pp.dat', 'w') as f:
            df_p.to_csv(
                        f, sep='\t',
                        header=False,
                        index=False,
                        line_terminator='\n',
                        encoding='utf-8'
                        )
        print(os.path.basename(f'{i}0pp.dat') + " file is overwritten successfully!")


def time_stamp(des):
    time = datetime.now().strftime('[%m/%d/%y %H:%M:%S]')
    print('\n' + 35*'+ ')
    print(time + ' |  {} ...'.format(des))
    print(35*'+ ' + '\n')

def modify_riv_pars():
    des = "updating river parameters"
    time_stamp(des)
    swatmf_pst_par.riv_par(wd)

def modify_hk_sy_pars_pp(pp_included):
    des = "modifying MODFLOW HK, VHK, and SY parameters"
    time_stamp(des)
    data_fac = pp_included
    for i in data_fac:
        outfile = i + '.ref'
        pyemu.utils.geostats.fac2real(i, factors_file=i+'.fac', out_file=outfile)

def execute_swat_edit():
    des = "modifying SWAT parameters"
    time_stamp(des)
    pyemu.os_utils.run('Swat_Edit.exe', cwd='.')

def execute_swatmf():
    des = "running model"
    time_stamp(des)
    # pyemu.os_utils.run('APEX-MODFLOW3.exe >_s+m.stdout', cwd='.')
    # pyemu.os_utils.run('swat2012_rev220620_r02.exe', cwd='.')
    pyemu.os_utils.run('swat_rev220630.exe', cwd='.')
def extract_stf_results(subs, sim_start, warmup, cal_start, cal_end):
    if time_step == 'day':
        des = "simulation successfully completed | extracting daily simulated streamflow"
        time_stamp(des)
        swatmf_pst_utils.extract_day_stf(subs, sim_start, warmup, cal_start, cal_end)
    elif time_step == 'month':
        des = "simulation successfully completed | extracting monthly simulated streamflow"
        time_stamp(des)
        swatmf_pst_utils.extract_month_stf(subs, sim_start, warmup, cal_start, cal_end)

def extract_gw_level_results(grids, sim_start, cal_end):
    des = "simulation successfully completed | extracting depth to water values"
    time_stamp(des)
    swatmf_pst_utils.extract_depth_to_water(grids, sim_start, cal_end)

def extract_baseflow_results(subs, sim_start, cal_start, cal_end):
    des = "simulation successfully completed | calculating baseflow ratio"
    time_stamp(des)
    swatmf_pst_utils.extract_month_baseflow(subs, sim_start, cal_start, cal_end)

# this part is gumu
def extract_hg_wt_mean(hg_wt_subs, sim_start, warmup, cal_start, cal_end, dates):
    hg_rch_file = 'output-mercury.rch'
    sim_start =  sim_start[:-4] + str(int(sim_start[-4:])+ int(warmup))
    hg_df = pd.read_csv(hg_rch_file,
                        delim_whitespace=True,
                        skiprows=2,
                        usecols=["RCH", "Hg2PmgSto"],
                        index_col=0
                    )
    hg_df = hg_df.loc["REACH"]
    hg_wt_sims = pd.DataFrame()
    for i in hg_wt_subs:
        hg_dff = hg_df.loc[hg_df["RCH"] == int(i)]
        hg_dff.index = pd.date_range(sim_start, periods=len(hg_dff))
        hg_dfs = hg_dff[cal_start:cal_end]
        hg_dfs = hg_dfs.rename({'Hg2PmgSto': 'sub{:03d}'.format(i)}, axis=1)
        hg_wt_sims = pd.concat([hg_wt_sims, hg_dfs.loc[:, 'sub{:03d}'.format(i)]], axis=1)
    hg_wt_sims.index = pd.to_datetime(hg_wt_sims.index)
    hg_wt_simss = hg_wt_sims.loc[dates].mean()
    dff = pd.DataFrame(hg_wt_simss).T
    dff.index = pd.to_datetime([cal_end])
    for j in hg_wt_subs:
        dff['sub{:03d}'.format(j)].to_csv(
                'hg_wt_{:03d}.txt'.format(j),
                sep='\t', encoding='utf-8', index=True, header=False,
                float_format='%.7e')
        print('hg_wt_{:03d}.txt file has been created...'.format(j))
    print('Finished ...')

def extract_hg_sed_mean(hg_sed_subs, sim_start, warmup, cal_start, cal_end, dates):
    hg_rch_file = 'output-mercury.rch'
    sim_start =  sim_start[:-4] + str(int(sim_start[-4:])+ int(warmup))
    hg_df = pd.read_csv(hg_rch_file,
                        delim_whitespace=True,
                        skiprows=2,
                        usecols=["RCH", "SedTHgCppm"],
                        index_col=0
                    )
    hg_df = hg_df.loc["REACH"]
    hg_sed_sims = pd.DataFrame()
    for i in hg_sed_subs:
        hg_dff = hg_df.loc[hg_df["RCH"] == int(i)]
        hg_dff.index = pd.date_range(sim_start, periods=len(hg_dff))
        hg_dfs = hg_dff[cal_start:cal_end]
        hg_dfs = hg_dfs.rename({'SedTHgCppm': 'sub{:03d}'.format(i)}, axis=1)
        hg_sed_sims = pd.concat([hg_sed_sims, hg_dfs.loc[:, 'sub{:03d}'.format(i)]], axis=1)
    hg_sed_sims.index = pd.to_datetime(hg_sed_sims.index)
    hg_sed_sims_mon = hg_sed_sims.resample('M').mean()
    hg_sed_simss = hg_sed_sims_mon.loc[dates].mean()
    dff = pd.DataFrame(hg_sed_simss).T
    dff.index = pd.to_datetime([cal_end])
    for j in hg_sed_subs:
        dff['sub{:03d}'.format(j)].to_csv(
                'hg_sed_{:03d}.txt'.format(j),
                sep='\t', encoding='utf-8', index=True, header=False,
                float_format='%.7e')
        print('hg_sed_{:03d}.txt file has been created...'.format(j))
    print('Finished ...')

###


if __name__ == '__main__':
    
    os.chdir(wd)
    swatmf_con = pd.read_csv('swatmf.con', sep='\t', names=['names', 'vals'], index_col=0, comment="#")
    # get default vals
    # wd = swatmf_con.loc['wd', 'vals']
    sim_start = swatmf_con.loc['sim_start', 'vals']
    warmup = swatmf_con.loc['warm-up', 'vals']
    cal_start = swatmf_con.loc['cal_start', 'vals']
    cal_end = swatmf_con.loc['cal_end', 'vals']
    cha_act = swatmf_con.loc['subs','vals']
    grid_act = swatmf_con.loc['grids','vals']
    riv_parm = swatmf_con.loc['riv_parm', 'vals']
    baseflow_act = swatmf_con.loc['baseflow', 'vals']
    time_step = swatmf_con.loc['time_step','vals']
    pp_act = swatmf_con.loc['pp_included', 'vals']
    
    # modifying river pars
    # if swatmf_con.loc['riv_parm', 'vals'] != 'n':
    modify_riv_pars()
    hksy_postcal()
    if swatmf_con.loc['pp_included', 'vals'] != 'n':
        pp_included = swatmf_con.loc['pp_included','vals'].strip('][').split(', ')
        pp_included = [i.replace("'", "").strip() for i in pp_included]  
        modify_hk_sy_pars_pp(pp_included)
    # execute model
    execute_swat_edit()
    hruSurlag()

    execute_swatmf()
    # extract sims
    # if swatmf_con.loc['cha_file', 'vals'] != 'n' and swatmf_con.loc['fdc', 'vals'] != 'n':
    if swatmf_con.loc['subs', 'vals'] != 'n':
        subs = swatmf_con.loc['subs','vals'].strip('][').split(', ')
        subs = [int(i) for i in subs]
        extract_stf_results(subs, sim_start, warmup, cal_start, cal_end)
    if swatmf_con.loc['grids', 'vals'] != 'n':
        grids = swatmf_con.loc['grids','vals'].strip('][').split(', ')
        grids = [int(i) for i in grids]        
        extract_gw_level_results(grids, sim_start, cal_end)

    # # this port is gumu
    # hg_wt_subs = [3, 4, 9, 11]
    # hg_wt_dates = ['6/3/2020', '9/21/2020', '12/7/2020', '3/3/2021', '8/30/2021']
    # extract_hg_wt_mean(hg_wt_subs, sim_start, warmup, cal_start, cal_end, hg_wt_dates)
    
    # hg_sed_subs = [2, 3, 4, 5, 9, 11]
    # hg_sed_dates = ['6/30/2020', '12/31/2020', '11/30/2021']
    # extract_hg_sed_mean(hg_sed_subs, sim_start, warmup, cal_start, cal_end, hg_sed_dates)
    # ##

    print(wd)




